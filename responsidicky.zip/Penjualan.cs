using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectPenjualan
{
    public class Penjualan
    {
    public string Nota { get; set; }
	public  string Tanggal { get; set; }

    public  string Costumer { get; set; }

    public  string Jenis { get; set; }

    public double Total { get; set; }

    }
}
